import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const links = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "skills", label: "Stack" },
  { id: "projects", label: "Work" },
  { id: "terminal", label: "Terminal" },
  { id: "contact", label: "Contact" },
];

export function Nav() {
  const [active, setActive] = useState("home");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => { if (e.isIntersecting) setActive(e.target.id); });
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    links.forEach((l) => { const el = document.getElementById(l.id); if (el) io.observe(el); });
    return () => { window.removeEventListener("scroll", onScroll); io.disconnect(); };
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.4, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed left-1/2 top-4 z-50 -translate-x-1/2 px-3 w-[min(96%,720px)]"
    >
      <div className={`glass-strong flex items-center justify-between rounded-full px-3 py-2 transition-all ${scrolled ? "glow-ring" : ""}`}>
        <a href="#home" className="flex items-center gap-2 pl-2 pr-3">
          <span className="relative inline-flex h-2 w-2 rounded-full bg-[color:var(--neon-3)] animate-pulse-glow" />
          <span className="font-mono text-xs tracking-widest text-foreground/80">AX/DEV</span>
        </a>
        <nav className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <a key={l.id} href={`#${l.id}`}
               className={`relative rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${active === l.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              {active === l.id && (
                <motion.span layoutId="nav-pill" className="absolute inset-0 -z-10 rounded-full bg-white/5 ring-1 ring-[color:var(--neon)]/30" transition={{ type: "spring", stiffness: 400, damping: 32 }} />
              )}
              {l.label}
            </a>
          ))}
        </nav>
        <a href="#contact" className="group relative ml-2 hidden sm:inline-flex items-center gap-1.5 rounded-full bg-[color:var(--neon)] px-4 py-1.5 text-xs font-semibold text-[color:var(--primary-foreground)] shadow-[0_0_30px_-6px_var(--neon)] transition-transform hover:scale-[1.03]">
          Let's talk →
        </a>
        <a href="#contact" className="sm:hidden mr-1 inline-flex rounded-full bg-[color:var(--neon)] px-3 py-1.5 text-xs font-semibold text-[color:var(--primary-foreground)]">Talk</a>
      </div>
    </motion.header>
  );
}
