import { motion } from "framer-motion";
import { useState } from "react";
import { Send, Github, Linkedin, Mail, Twitter } from "lucide-react";
import { SectionLabel } from "./About";

export function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="relative py-32">
      <div className="container mx-auto px-6">
        <SectionLabel kicker="05 / SIGNAL" title="Let's build something inevitable." />

        <div className="mt-16 grid lg:grid-cols-[1.1fr_1fr] gap-6">
          <motion.form initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            onSubmit={(e) => { e.preventDefault(); setSent(true); setTimeout(() => setSent(false), 3500); }}
            className="relative glass-strong rounded-3xl p-8 lg:p-10 overflow-hidden">
            <div className="absolute -top-32 -left-32 h-72 w-72 rounded-full opacity-30 blur-3xl" style={{ background: "var(--neon)" }} />
            <div className="absolute -bottom-32 -right-32 h-72 w-72 rounded-full opacity-30 blur-3xl" style={{ background: "var(--neon-2)" }} />
            <div className="relative grid gap-5">
              {[{ id: "name", label: "Your name", type: "text" }, { id: "email", label: "Email", type: "email" }].map((f) => (
                <Field key={f.id} {...f} />
              ))}
              <Field id="msg" label="What are you building?" textarea />
              <button type="submit"
                className="group relative mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-[color:var(--neon)] px-6 py-3 font-semibold text-[color:var(--primary-foreground)] shadow-[0_0_40px_-8px_var(--neon)] transition-transform hover:scale-[1.02]">
                {sent ? "Message sent ✓" : "Transmit"} <Send className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </motion.form>

          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="space-y-4">
            <div className="glass-strong rounded-3xl p-6">
              <div className="font-mono text-[10px] tracking-widest text-muted-foreground">LOCATION</div>
              <div className="mt-1 text-xl font-semibold">Lisbon · UTC+0</div>
              <div className="text-sm text-muted-foreground">Open to remote · happy to fly for great teams.</div>
            </div>
            <div className="glass-strong rounded-3xl p-6">
              <div className="font-mono text-[10px] tracking-widest text-muted-foreground">DIRECT</div>
              <a href="mailto:hello@alex.dev" className="mt-1 block text-xl font-semibold text-gradient">hello@alex.dev</a>
              <div className="text-sm text-muted-foreground">Avg. reply &lt; 6h.</div>
            </div>
            <div className="glass-strong rounded-3xl p-6">
              <div className="font-mono text-[10px] tracking-widest text-muted-foreground mb-3">CHANNELS</div>
              <div className="grid grid-cols-4 gap-2">
                {[Github, Linkedin, Twitter, Mail].map((Icon, i) => (
                  <a key={i} href="#" className="grid h-14 place-items-center rounded-2xl glass hover:glow-ring transition">
                    <Icon className="h-5 w-5" />
                  </a>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <footer className="container mx-auto px-6 mt-24 border-t border-white/5 pt-8 flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground font-mono">
        <div>© 2026 Alex Reyes — crafted with intent.</div>
        <div className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--neon-3)] animate-pulse-glow" />
          All systems nominal
        </div>
      </footer>
    </section>
  );
}

function Field({ id, label, type = "text", textarea = false }: { id: string; label: string; type?: string; textarea?: boolean }) {
  const [focus, setFocus] = useState(false);
  const [val, setVal] = useState("");
  const active = focus || val.length > 0;
  const cls = "peer w-full bg-transparent outline-none border-b border-white/10 pt-6 pb-2 text-base focus:border-[color:var(--neon)] transition-colors";
  return (
    <div className="relative">
      {textarea ? (
        <textarea id={id} rows={3} value={val} onChange={(e) => setVal(e.target.value)}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} className={cls + " resize-none"} />
      ) : (
        <input id={id} type={type} value={val} onChange={(e) => setVal(e.target.value)}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} className={cls} />
      )}
      <label htmlFor={id} className={`pointer-events-none absolute left-0 transition-all font-mono ${active ? "top-0 text-[10px] tracking-widest text-[color:var(--neon)]" : "top-6 text-sm text-muted-foreground"}`}>
        {label}
      </label>
    </div>
  );
}
