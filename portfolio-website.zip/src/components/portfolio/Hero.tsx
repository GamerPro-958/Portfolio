import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useEffect, useState } from "react";
import { ArrowDown, Github, Linkedin, Mail, Sparkles } from "lucide-react";

const SCRAMBLE = "!<>-_\\/[]{}—=+*^?#________";

function useScramble(target: string, trigger = true, speed = 40) {
  const [text, setText] = useState(target);
  useEffect(() => {
    if (!trigger) return;
    let frame = 0;
    const queue: { from: string; to: string; start: number; end: number; char?: string }[] = [];
    const length = Math.max(text.length, target.length);
    for (let i = 0; i < length; i++) {
      queue.push({ from: text[i] || "", to: target[i] || "", start: Math.floor(Math.random() * 20), end: Math.floor(Math.random() * 20) + 20 });
    }
    let id: number;
    const tick = () => {
      let out = ""; let complete = 0;
      for (const q of queue) {
        if (frame >= q.end) { complete++; out += q.to; }
        else if (frame >= q.start) {
          if (!q.char || Math.random() < 0.28) q.char = SCRAMBLE[Math.floor(Math.random() * SCRAMBLE.length)];
          out += `<span style="color:var(--neon-2);opacity:.7">${q.char}</span>`;
        } else out += q.from;
      }
      setText(out);
      if (complete < queue.length) { frame++; id = window.setTimeout(tick, speed); }
    };
    tick();
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, trigger]);
  return text;
}

export function Hero() {
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rx = useSpring(useTransform(my, [-0.5, 0.5], [8, -8]), { stiffness: 120, damping: 20 });
  const ry = useSpring(useTransform(mx, [-0.5, 0.5], [-8, 8]), { stiffness: 120, damping: 20 });

  const scrambled = useScramble("FULLSTACK ENGINEER");

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-28 pb-20"
      onPointerMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        mx.set((e.clientX - r.left) / r.width - 0.5);
        my.set((e.clientY - r.top) / r.height - 0.5);
      }}>
      <div className="container mx-auto px-6 grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
        <div>
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 glass rounded-full px-3 py-1.5 text-xs font-mono">
            <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--neon-3)] animate-pulse-glow" />
            <span className="text-muted-foreground">Available for senior roles · Q3 2026</span>
          </motion.div>

          <h1 className="mt-6 font-display text-5xl sm:text-7xl lg:text-[5.5rem] font-bold leading-[0.95] tracking-tight">
            {["Building", "the", "future,"].map((w, i) => (
              <motion.span key={i} initial={{ opacity: 0, y: 30, filter: "blur(10px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ delay: 0.3 + i * 0.08, duration: 0.8, ease: [0.22, 1, 0.36, 1] }} className="inline-block mr-3">{w}</motion.span>
            ))}
            <br />
            <motion.span initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.8 }}
              className="text-gradient text-shadow-glow">one commit at a time.</motion.span>
          </h1>

          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}
            className="mt-6 max-w-xl text-base sm:text-lg text-muted-foreground leading-relaxed">
            I'm <span className="text-foreground">Alex Reyes</span> — a fullstack engineer designing immersive interfaces and scalable systems for AI-native products. Currently shipping at the edge of React 19, Rust services, and real-time ML.
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.05 }}
            className="mt-4 font-mono text-xs tracking-[0.3em] text-[color:var(--neon)]"
            dangerouslySetInnerHTML={{ __html: `// ${scrambled}` }} />

          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.2 }}
            className="mt-8 flex flex-wrap items-center gap-3">
            <a href="#projects" className="group relative inline-flex items-center gap-2 rounded-full bg-[color:var(--neon)] px-6 py-3 text-sm font-semibold text-[color:var(--primary-foreground)] shadow-[0_0_40px_-8px_var(--neon)] transition-transform hover:scale-[1.04]">
              <Sparkles className="h-4 w-4" /> View selected work
              <span className="absolute inset-0 rounded-full ring-1 ring-white/20 transition group-hover:ring-white/40" />
            </a>
            <a href="#contact" className="inline-flex items-center gap-2 rounded-full glass px-6 py-3 text-sm font-medium hover:bg-white/10 transition">
              Get in touch
            </a>
            <div className="flex items-center gap-2 ml-2">
              {[{ Icon: Github, href: "#" }, { Icon: Linkedin, href: "#" }, { Icon: Mail, href: "#contact" }].map(({ Icon, href }, i) => (
                <a key={i} href={href} className="grid h-10 w-10 place-items-center rounded-full glass hover:glow-ring transition">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Profile card */}
        <motion.div style={{ rotateX: rx, rotateY: ry, transformPerspective: 1000 }}
          initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.5, duration: 1 }}
          className="relative mx-auto w-full max-w-md">
          <div className="absolute -inset-6 rounded-full opacity-50 blur-3xl" style={{ background: "var(--gradient-text)" }} />
          <div className="relative aspect-square rounded-[2rem] glass-strong glow-ring p-1 animate-float">
            <div className="relative h-full w-full overflow-hidden rounded-[1.8rem] bg-gradient-to-br from-[oklch(0.2_0.05_270)] to-[oklch(0.15_0.04_280)]">
              {/* Holographic avatar */}
              <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full">
                <defs>
                  <radialGradient id="g1" cx="50%" cy="40%">
                    <stop offset="0%" stopColor="oklch(0.85 0.18 320)" />
                    <stop offset="50%" stopColor="oklch(0.6 0.18 270)" />
                    <stop offset="100%" stopColor="oklch(0.2 0.05 270)" />
                  </radialGradient>
                  <linearGradient id="g2" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="oklch(0.82 0.2 195)" />
                    <stop offset="100%" stopColor="oklch(0.72 0.24 320)" />
                  </linearGradient>
                </defs>
                <circle cx="200" cy="170" r="70" fill="url(#g1)" />
                <path d="M80 360 Q 200 240 320 360 L 320 400 L 80 400 Z" fill="url(#g1)" />
                {/* Holographic rings */}
                {[0,1,2,3].map(i => (
                  <circle key={i} cx="200" cy="200" r={120 + i*25} fill="none" stroke="url(#g2)" strokeWidth="0.5" opacity={0.3 - i*0.05} />
                ))}
                <g opacity="0.4" stroke="oklch(0.82 0.2 195)" strokeWidth="0.5" fill="none">
                  {Array.from({ length: 14 }).map((_, i) => (
                    <line key={i} x1="0" y1={i * 28} x2="400" y2={i * 28} />
                  ))}
                </g>
              </svg>
              <div className="absolute inset-0 mix-blend-overlay opacity-30" style={{ background: "var(--gradient-aurora)" }} />
              <div className="absolute bottom-4 left-4 right-4 glass rounded-xl p-3 flex items-center justify-between">
                <div>
                  <div className="font-mono text-[10px] text-muted-foreground tracking-widest">STATUS</div>
                  <div className="text-sm font-semibold flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--neon-3)] animate-pulse-glow" />
                    Online · Open to work
                  </div>
                </div>
                <div className="font-mono text-[10px] text-[color:var(--neon)]">v3.26.1</div>
              </div>
            </div>
          </div>

          {/* Floating panels */}
          <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 5, repeat: Infinity }}
            className="absolute -left-6 top-10 glass rounded-2xl p-3 font-mono text-[11px] hidden sm:block">
            <div className="text-muted-foreground">$ uptime</div>
            <div className="text-[color:var(--neon)]">99.98% · 7y shipping</div>
          </motion.div>
          <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 6, repeat: Infinity, delay: 1 }}
            className="absolute -right-4 bottom-16 glass rounded-2xl p-3 font-mono text-[11px] hidden sm:block">
            <div className="text-muted-foreground">latency</div>
            <div className="text-[color:var(--neon-2)]">12ms · global</div>
          </motion.div>
        </motion.div>
      </div>

      <a href="#about" className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-xs text-muted-foreground">
        <span className="font-mono tracking-widest">SCROLL</span>
        <motion.span animate={{ y: [0, 6, 0] }} transition={{ duration: 1.6, repeat: Infinity }}>
          <ArrowDown className="h-4 w-4" />
        </motion.span>
      </a>
    </section>
  );
}
