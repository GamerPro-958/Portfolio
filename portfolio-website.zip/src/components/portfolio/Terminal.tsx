import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { SectionLabel } from "./About";

type Line = { kind: "in" | "out" | "sys"; text: string };

const RESPONSES: Record<string, string> = {
  help: "Available: about · skills · projects · contact · socials · resume · clear",
  about: "Alex Reyes — fullstack engineer · 7y · ex-Lumen AI, Nexora Labs. Based in Lisbon.",
  skills: "TS, React, Rust, Go, Postgres, K8s, AI infra. See #skills for the full stack.",
  projects: "Neuron OS · Loom Studio · Atlas · Halo · Vector.fm. Scroll to #projects for case studies.",
  contact: "hello@alex.dev · scroll to #contact, or press the Talk button.",
  socials: "github.com/alexr · linkedin.com/in/alexr · x.com/alexr",
  resume: "↳ Downloading resume.pdf … (demo)",
};

export function Terminal() {
  const [lines, setLines] = useState<Line[]>([
    { kind: "sys", text: "axOS v3.26.1 — type 'help' to begin." },
  ]);
  const [value, setValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => { boxRef.current?.scrollTo({ top: 99999, behavior: "smooth" }); }, [lines]);

  const submit = (raw: string) => {
    const cmd = raw.trim().toLowerCase();
    if (!cmd) return;
    if (cmd === "clear") { setLines([{ kind: "sys", text: "Cleared." }]); return; }
    const out = RESPONSES[cmd] ?? `command not found: ${cmd} — try 'help'`;
    setLines((l) => [...l, { kind: "in", text: raw }, { kind: "out", text: out }]);
  };

  return (
    <section id="terminal" className="relative py-32">
      <div className="container mx-auto px-6">
        <SectionLabel kicker="04 / SYSTEM" title="Talk to the machine." />
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          onClick={() => inputRef.current?.focus()}
          className="mt-12 glass-strong rounded-3xl overflow-hidden glow-ring cursor-text">
          <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
            <span className="h-3 w-3 rounded-full bg-red-400/80" />
            <span className="h-3 w-3 rounded-full bg-yellow-400/80" />
            <span className="h-3 w-3 rounded-full bg-green-400/80" />
            <span className="ml-3 font-mono text-xs text-muted-foreground">~/alex — zsh</span>
            <span className="ml-auto font-mono text-[10px] text-[color:var(--neon)]">SECURE · TLS</span>
          </div>
          <div ref={boxRef} className="font-mono text-sm p-5 h-[340px] overflow-y-auto scrollbar-hide leading-relaxed">
            {lines.map((l, i) => (
              <div key={i} className={l.kind === "in" ? "text-foreground" : l.kind === "sys" ? "text-[color:var(--neon-2)]" : "text-muted-foreground"}>
                {l.kind === "in" && <span className="text-[color:var(--neon)] mr-2">➜</span>}
                {l.text}
              </div>
            ))}
            <form onSubmit={(e) => { e.preventDefault(); submit(value); setValue(""); }} className="flex items-center mt-1">
              <span className="text-[color:var(--neon)] mr-2">➜</span>
              <input ref={inputRef} value={value} onChange={(e) => setValue(e.target.value)} autoComplete="off" spellCheck={false}
                className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground" placeholder="type a command…" />
              <span className="ml-1 inline-block h-4 w-2 bg-[color:var(--neon)] animate-blink" />
            </form>
          </div>
          <div className="border-t border-white/10 px-4 py-2 flex flex-wrap gap-2">
            {Object.keys(RESPONSES).map((c) => (
              <button key={c} onClick={() => submit(c)} className="rounded-full glass px-2.5 py-1 text-[10px] font-mono hover:border-[color:var(--neon)]/40">{c}</button>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
