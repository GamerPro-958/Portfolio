import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";

export function Loader() {
  const [pct, setPct] = useState(0);
  const [done, setDone] = useState(false);
  useEffect(() => {
    let p = 0;
    const id = setInterval(() => {
      p += Math.random() * 18 + 6;
      if (p >= 100) { p = 100; clearInterval(id); setTimeout(() => setDone(true), 350); }
      setPct(Math.floor(p));
    }, 90);
    return () => clearInterval(id);
  }, []);
  return (
    <AnimatePresence>
      {!done && (
        <motion.div className="fixed inset-0 z-[200] grid place-items-center bg-background"
          exit={{ opacity: 0, filter: "blur(20px)" }} transition={{ duration: 0.7 }}>
          <div className="absolute inset-0 aurora-bg opacity-50" />
          <div className="absolute inset-0 grid-overlay opacity-30" />
          <div className="relative flex flex-col items-center gap-6">
            <div className="font-mono text-[10px] tracking-[0.5em] text-[color:var(--neon)]">INITIALIZING SYSTEM</div>
            <div className="text-6xl sm:text-8xl font-bold text-gradient tabular-nums">{String(pct).padStart(3, "0")}</div>
            <div className="h-px w-64 bg-white/10 overflow-hidden">
              <motion.div className="h-full bg-[color:var(--neon)]" style={{ width: `${pct}%` }} />
            </div>
            <div className="font-mono text-[10px] tracking-widest text-muted-foreground">AX/OS · BOOTING KERNEL</div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
