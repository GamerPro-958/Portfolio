import { motion, useInView } from "framer-motion";
import { useEffect, useRef, useState } from "react";

function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1600;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const e = 1 - Math.pow(1 - p, 3);
      setN(Math.round(to * e));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, to]);
  return <span ref={ref}>{n}{suffix}</span>;
}

const timeline = [
  { year: "2025", role: "Staff Engineer", company: "Lumen AI", note: "Real-time multimodal agents on edge GPU." },
  { year: "2023", role: "Senior Fullstack", company: "Nexora Labs", note: "Shipped a design tool used by 120k creators." },
  { year: "2021", role: "Product Engineer", company: "Helix", note: "Built core infra for healthcare data pipelines." },
  { year: "2019", role: "Founding Engineer", company: "Drift.dev", note: "0→1 dev tooling startup, acquired in 2022." },
];

export function About() {
  return (
    <section id="about" className="relative py-32">
      <div className="container mx-auto px-6">
        <SectionLabel kicker="01 / IDENTITY" title="Engineer, designer, & systems thinker." />

        <div className="mt-16 grid lg:grid-cols-3 gap-6">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="lg:col-span-2 glass-strong rounded-3xl p-8 lg:p-10">
            <p className="text-xl lg:text-2xl leading-relaxed text-foreground/90">
              I move fluidly between <span className="text-gradient font-semibold">pixel-perfect interfaces</span> and the systems that power them — distributed backends, real-time pipelines, and AI infrastructure. My focus is shipping products that feel inevitable.
            </p>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              Previously I led platform teams at Lumen AI and Nexora Labs, scaling products from prototype to millions of requests per day. Today I consult with founders, design teams, and ML labs that want frontends with the polish of Apple and the depth of Linear.
            </p>

            <div className="mt-8 grid grid-cols-3 gap-4">
              {[
                { n: 7, s: "+", label: "Years shipping" },
                { n: 42, s: "", label: "Products launched" },
                { n: 99, s: "%", label: "Uptime delivered" },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl glass p-4">
                  <div className="text-3xl lg:text-4xl font-bold text-gradient">
                    <Counter to={s.n} suffix={s.s} />
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground font-mono uppercase tracking-widest">{s.label}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="glass-strong rounded-3xl p-6 lg:p-8">
            <div className="font-mono text-[10px] tracking-widest text-muted-foreground mb-6">TIMELINE</div>
            <ol className="space-y-5 relative">
              <span className="absolute left-[7px] top-1 bottom-1 w-px bg-gradient-to-b from-[color:var(--neon)] via-[color:var(--neon-2)] to-transparent" />
              {timeline.map((t, i) => (
                <motion.li key={i} initial={{ opacity: 0, x: 10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }} className="relative pl-6">
                  <span className="absolute left-0 top-1.5 h-3.5 w-3.5 rounded-full bg-background ring-2 ring-[color:var(--neon)]" />
                  <div className="flex items-baseline gap-2">
                    <span className="font-mono text-xs text-[color:var(--neon)]">{t.year}</span>
                    <span className="text-sm font-semibold">{t.role}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{t.company} — {t.note}</div>
                </motion.li>
              ))}
            </ol>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export function SectionLabel({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div>
      <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="font-mono text-[11px] tracking-[0.4em] text-[color:var(--neon)]">{kicker}</motion.div>
      <motion.h2 initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        transition={{ delay: 0.05 }}
        className="mt-3 text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight max-w-3xl">{title}</motion.h2>
    </div>
  );
}
