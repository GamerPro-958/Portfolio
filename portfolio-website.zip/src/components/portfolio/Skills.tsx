import { motion } from "framer-motion";
import { SectionLabel } from "./About";

const groups = [
  { title: "Frontend", color: "var(--neon)", items: ["React 19", "TypeScript", "Next.js", "Tailwind", "Framer Motion", "Three.js", "GSAP", "WebGL"] },
  { title: "Backend", color: "var(--neon-2)", items: ["Node.js", "Rust", "Go", "PostgreSQL", "Redis", "tRPC", "GraphQL", "gRPC"] },
  { title: "Infra & AI", color: "var(--neon-3)", items: ["AWS", "Cloudflare", "Kubernetes", "Terraform", "OpenAI", "LangChain", "Pinecone", "Modal"] },
];

const orbit = ["TS", "RS", "GO", "PY", "SQL", "K8s", "AI", "GPU"];

export function Skills() {
  return (
    <section id="skills" className="relative py-32">
      <div className="container mx-auto px-6">
        <SectionLabel kicker="02 / CAPABILITIES" title="A stack tuned for shipping." />

        <div className="mt-16 grid lg:grid-cols-[1.4fr_1fr] gap-6">
          <div className="grid sm:grid-cols-3 gap-4">
            {groups.map((g, i) => (
              <motion.div key={g.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="group relative glass-strong rounded-3xl p-6 overflow-hidden">
                <div className="absolute -top-20 -right-20 h-40 w-40 rounded-full opacity-30 blur-3xl transition-opacity group-hover:opacity-60"
                     style={{ background: g.color as string }} />
                <div className="font-mono text-[10px] tracking-widest text-muted-foreground">/ {String(i + 1).padStart(2, "0")}</div>
                <h3 className="mt-2 text-2xl font-bold">{g.title}</h3>
                <ul className="mt-5 flex flex-wrap gap-2">
                  {g.items.map((it) => (
                    <li key={it} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs font-mono hover:border-[color:var(--neon)]/40 hover:text-foreground transition">
                      {it}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

          {/* Orbit visualization */}
          <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            className="relative glass-strong rounded-3xl p-6 min-h-[320px] flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 grid-overlay opacity-30" />
            <div className="relative h-72 w-72">
              {[120, 90, 60].map((r, ringIdx) => (
                <motion.div key={r} className="absolute inset-0 rounded-full border border-[color:var(--neon)]/20"
                  style={{ inset: `calc(50% - ${r}px)`, width: r * 2, height: r * 2 }}
                  animate={{ rotate: ringIdx % 2 === 0 ? 360 : -360 }}
                  transition={{ duration: 18 + ringIdx * 6, repeat: Infinity, ease: "linear" }}>
                  {orbit.slice(ringIdx * 3, ringIdx * 3 + 3).map((label, i, arr) => {
                    const angle = (i / arr.length) * Math.PI * 2;
                    const x = Math.cos(angle) * r;
                    const y = Math.sin(angle) * r;
                    return (
                      <div key={label}
                        className="absolute left-1/2 top-1/2 grid h-10 w-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full glass font-mono text-[10px] glow-ring"
                        style={{ transform: `translate(${x - 20}px, ${y - 20}px)` }}>
                        {label}
                      </div>
                    );
                  })}
                </motion.div>
              ))}
              <div className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-2xl glass-strong font-mono text-xs glow-ring-magenta">
                CORE
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
