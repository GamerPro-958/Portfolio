import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ArrowUpRight, Github, X } from "lucide-react";
import { SectionLabel } from "./About";

type Project = {
  id: string;
  title: string;
  tag: string;
  year: string;
  blurb: string;
  desc: string;
  stack: string[];
  span: string;
  gradient: string;
};

const projects: Project[] = [
  { id: "neuron", title: "Neuron OS", tag: "AI Platform", year: "2025", blurb: "Real-time agent runtime", desc: "An edge-deployed runtime that orchestrates multimodal agents with sub-50ms latency. Built with Rust, WebGPU, and a custom event-sourced state machine.",
    stack: ["Rust", "WebGPU", "React", "Cloudflare"], span: "lg:col-span-2 lg:row-span-2", gradient: "linear-gradient(135deg, oklch(0.55 0.22 280), oklch(0.45 0.2 200))" },
  { id: "loom", title: "Loom Studio", tag: "Design Tool", year: "2024", blurb: "Collaborative motion editor", desc: "Browser-native motion design tool with realtime CRDT collaboration and a GPU compositor.",
    stack: ["TS", "WASM", "Yjs"], span: "lg:col-span-2", gradient: "linear-gradient(135deg, oklch(0.6 0.2 320), oklch(0.4 0.15 290))" },
  { id: "atlas", title: "Atlas", tag: "Infra", year: "2024", blurb: "Edge data layer", desc: "Globally distributed data layer with strong consistency, powering 8B reads/day.",
    stack: ["Go", "Postgres", "Kafka"], span: "", gradient: "linear-gradient(135deg, oklch(0.55 0.2 160), oklch(0.4 0.15 200))" },
  { id: "halo", title: "Halo", tag: "Consumer", year: "2023", blurb: "Wellness companion", desc: "Mobile-first companion app with on-device ML and a custom haptic engine.",
    stack: ["React Native", "Swift", "CoreML"], span: "", gradient: "linear-gradient(135deg, oklch(0.7 0.18 50), oklch(0.45 0.2 20))" },
  { id: "vector", title: "Vector.fm", tag: "Devtool", year: "2023", blurb: "Embeddings playground", desc: "Open-source playground for visualizing & debugging vector spaces in 3D.",
    stack: ["Three.js", "Python", "FastAPI"], span: "lg:col-span-2", gradient: "linear-gradient(135deg, oklch(0.6 0.2 230), oklch(0.45 0.18 320))" },
];

export function Projects() {
  const [active, setActive] = useState<Project | null>(null);
  const [filter, setFilter] = useState<string>("All");
  const tags = ["All", ...Array.from(new Set(projects.map((p) => p.tag)))];
  const shown = filter === "All" ? projects : projects.filter((p) => p.tag === filter);

  return (
    <section id="projects" className="relative py-32">
      <div className="container mx-auto px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionLabel kicker="03 / SELECTED WORK" title="Products built from kernel to canvas." />
          <div className="flex flex-wrap gap-2">
            {tags.map((t) => (
              <button key={t} onClick={() => setFilter(t)}
                className={`rounded-full px-3 py-1.5 text-xs font-mono transition border ${filter === t ? "bg-[color:var(--neon)] text-[color:var(--primary-foreground)] border-transparent" : "glass border-white/10 hover:border-[color:var(--neon)]/40"}`}>
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 auto-rows-[220px] gap-4">
          {shown.map((p, i) => (
            <motion.button key={p.id} layoutId={`card-${p.id}`} onClick={() => setActive(p)}
              initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -4 }}
              className={`group relative overflow-hidden rounded-3xl text-left glass-strong ${p.span}`}>
              <div className="absolute inset-0 opacity-70 transition-opacity group-hover:opacity-100" style={{ background: p.gradient }} />
              <div className="absolute inset-0 grid-overlay opacity-20" />
              <div className="absolute inset-0 noise" />
              <div className="relative h-full p-6 flex flex-col justify-between">
                <div className="flex items-start justify-between">
                  <span className="font-mono text-[10px] tracking-widest text-white/70">{p.tag} · {p.year}</span>
                  <ArrowUpRight className="h-5 w-5 text-white/80 transition-transform group-hover:rotate-45 group-hover:text-white" />
                </div>
                <div>
                  <h3 className="text-2xl lg:text-3xl font-bold text-white">{p.title}</h3>
                  <p className="mt-1 text-sm text-white/80">{p.blurb}</p>
                </div>
              </div>
              <div className="absolute inset-0 ring-1 ring-inset ring-white/10 group-hover:ring-white/30 rounded-3xl pointer-events-none" />
            </motion.button>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {active && (
          <motion.div className="fixed inset-0 z-[80] grid place-items-center p-4 sm:p-8"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-background/80 backdrop-blur-xl" onClick={() => setActive(null)} />
            <motion.div layoutId={`card-${active.id}`} className="relative w-full max-w-3xl overflow-hidden rounded-3xl glass-strong">
              <div className="absolute inset-0 opacity-60" style={{ background: active.gradient }} />
              <div className="absolute inset-0 grid-overlay opacity-30" />
              <div className="relative p-8 lg:p-12">
                <button onClick={() => setActive(null)} className="absolute right-5 top-5 grid h-9 w-9 place-items-center rounded-full glass hover:bg-white/15">
                  <X className="h-4 w-4" />
                </button>
                <div className="font-mono text-[11px] tracking-widest text-white/80">{active.tag} · {active.year}</div>
                <h3 className="mt-2 text-4xl lg:text-5xl font-bold text-white">{active.title}</h3>
                <p className="mt-5 text-white/85 text-lg leading-relaxed max-w-2xl">{active.desc}</p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {active.stack.map((s) => (
                    <span key={s} className="rounded-full glass px-3 py-1 text-xs font-mono">{s}</span>
                  ))}
                </div>
                <div className="mt-8 flex gap-3">
                  <a href="#" className="inline-flex items-center gap-2 rounded-full bg-[color:var(--neon)] px-5 py-2.5 text-sm font-semibold text-[color:var(--primary-foreground)]">
                    Live demo <ArrowUpRight className="h-4 w-4" />
                  </a>
                  <a href="#" className="inline-flex items-center gap-2 rounded-full glass px-5 py-2.5 text-sm font-medium">
                    <Github className="h-4 w-4" /> Source
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
