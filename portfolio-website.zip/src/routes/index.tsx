import { createFileRoute } from "@tanstack/react-router";
import { Background } from "@/components/portfolio/Background";
import { Cursor } from "@/components/portfolio/Cursor";
import { Nav } from "@/components/portfolio/Nav";
import { Hero } from "@/components/portfolio/Hero";
import { About } from "@/components/portfolio/About";
import { Skills } from "@/components/portfolio/Skills";
import { Projects } from "@/components/portfolio/Projects";
import { Terminal } from "@/components/portfolio/Terminal";
import { Contact } from "@/components/portfolio/Contact";
import { Loader } from "@/components/portfolio/Loader";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alex Reyes — Fullstack Engineer" },
      { name: "description", content: "Cinematic portfolio of Alex Reyes — a fullstack engineer building AI-native products with React, Rust, and edge infrastructure." },
      { property: "og:title", content: "Alex Reyes — Fullstack Engineer" },
      { property: "og:description", content: "Immersive portfolio: AI platforms, design tools, and edge infrastructure." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="relative">
      <Loader />
      <Background />
      <Cursor />
      <Nav />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Terminal />
        <Contact />
      </main>
    </div>
  );
}
